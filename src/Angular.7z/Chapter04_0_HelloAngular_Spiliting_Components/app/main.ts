
import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { MyDatePipe } from './custom/pipe/mydate.pipe'
import { AppComponent } from './app.component';
import { CarPartsComponent } from './car-parts.component';

@NgModule({
    declarations: [ AppComponent, CarPartsComponent, MyDatePipe ],
    imports: [BrowserModule],
    bootstrap: [ AppComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);