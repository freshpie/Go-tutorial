/**
 * Created by 206-001 on 2017-04-26.
 */
import { Component } from '@angular/core';

@Component({
    selector: 'copyright',
    template: `
        <p>Typescript와 Angular Application</p>
    `
})
export class CopyrightComponent {

}