/**
 * Created by 206-001 on 2017-04-26.
 */
import { Component } from '@angular/core';

@Component({
    selector: 'footer',
    template: `
        <address-data></address-data>
        <copyright></copyright>
    `
})
export class FooterComponent {

}