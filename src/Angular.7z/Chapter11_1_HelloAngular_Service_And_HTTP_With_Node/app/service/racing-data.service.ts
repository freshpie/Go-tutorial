/**
 * Created by 206-001 on 2017-04-27.
 */
import { CARPARTS } from '../car-parts/mocks';
import { Injectable } from '@angular/core';
import {CarPart} from "../car-parts/car-part";
import { Http } from "@angular/http";
import 'rxjs/add/operator/map';

@Injectable()
export class RacingDataService {

    constructor(private http: Http) {}

    getCarParts() {
        // return CARPARTS;
        return this.http.get("http://localhost:52273/data.json")
            .map(response => <CarPart[]> response.json().data);
    }

    addCarPart(carPart: CarPart) {
        CARPARTS.push(carPart);
        return this.getCarParts();
    }
}