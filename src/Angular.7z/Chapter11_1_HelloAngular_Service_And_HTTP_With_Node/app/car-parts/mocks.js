"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Created by 206-001 on 2017-04-26.
 */
exports.CARPARTS = [{
        "id": 1,
        "name": "Super Tires",
        "description": "These tires are the very best.",
        "inStock": 5,
        "price": 4.99,
        "image": "/images/tires.jpg",
        "featured": false,
        "quantity": 0
    }, {
        "id": 2,
        "name": "Reinforced Shocks",
        "description": "Shocks made from Kryptonite",
        "inStock": 4,
        "price": 9.99,
        "image": "/images/shocks.jpg",
        "featured": true,
        "quantity": 0
    }, {
        "id": 1,
        "name": "Padded Seats",
        "description": "Super soft seats for a smooth ride.",
        "inStock": 0,
        "price": 24.99,
        "image": "/images/seats.jpg",
        "featured": false,
        "quantity": 0
    }];
//# sourceMappingURL=mocks.js.map