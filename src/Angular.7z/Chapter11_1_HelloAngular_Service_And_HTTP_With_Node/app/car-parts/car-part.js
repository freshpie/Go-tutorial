"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Created by 206-001 on 2017-04-26.
 */
var CarPart = (function () {
    function CarPart() {
    }
    return CarPart;
}());
exports.CarPart = CarPart;
//# sourceMappingURL=car-part.js.map