/**
 * Created by 206-001 on 2017-04-25.
 */
import { Component } from '@angular/core';

@Component({
    selector: "my-app",
    template: `<h1>{{title}}</h1>
    <p>날짜변환 해보기 {{dateStr}} => {{dateStr | mydate:'-'}}</p>
    <car-parts></car-parts>
    <footer></footer>`
})
export class AppComponent {
    title= "Ultra Racing";
    dateStr = "20170425";
}