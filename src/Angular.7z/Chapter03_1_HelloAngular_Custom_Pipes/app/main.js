"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var mydate_pipe_1 = require("./custom/pipe/mydate.pipe");
var AppComponent = (function () {
    function AppComponent() {
        this.title = "Ultra Racing";
        this.count = 0;
        this.dateStr = "20170425";
        this.carParts = [{
                "id": 1,
                "name": "Super Tires",
                "description": "These tires are the very best.",
                "inStock": 5,
                "price": 4.99
            }, {
                "id": 2,
                "name": "Reinforced Shocks",
                "description": "Shocks made from Kryptonite",
                "inStock": 4,
                "price": 9.99
            }, {
                "id": 1,
                "name": "Padded Seats",
                "description": "Super soft seats for a smooth ride.",
                "inStock": 0,
                "price": 24.99
            }];
    }
    AppComponent.prototype.totalCarParts = function () {
        // let sum: number = 0;
        // for ( let carPart of this.carParts ) {
        //     sum += carPart.inStock;
        // }
        // return sum;
        // return this.carParts.reduce( function ( prev, current ) { return prev + current.inStock}, 0 );
        return this.carParts.reduce(function (prev, current) { return prev + current.inStock; }, 0);
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: "my-app",
        template: "<h1>{{title}}</h1>\n    <!--<h2>{{carPart.id}}</h2>-->\n    <p>There are {{totalCarParts()}} total parts in stock.</p>\n    <p>\uB0A0\uC9DC\uBCC0\uD658 \uD574\uBCF4\uAE30 {{dateStr}} => {{dateStr | mydate:'-'}}</p>\n    <ul>\n        <li *ngFor=\"let carPart of carParts; let i = index\">\n            <h2>{{i+1}}\uBC88\uC9F8 \uC544\uC774\uD15C : {{carPart.name | uppercase}}</h2>\n            <p>{{carPart.description}}</p>\n            <p>{{carPart.price | currency:'EUR':true}}</p>\n            <p *ngIf=\"carPart.inStock > 0\">{{carPart.inStock}} in Stock</p>\n            <p *ngIf=\"carPart.inStock === 0\">Out of Stock</p>\n        </li>\n    </ul>"
    })
], AppComponent);
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [AppComponent, mydate_pipe_1.MyDatePipe],
        imports: [platform_browser_1.BrowserModule],
        bootstrap: [AppComponent]
    })
], AppModule);
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(AppModule);
//# sourceMappingURL=main.js.map