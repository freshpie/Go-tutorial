/**
 * Created by 206-001 on 2017-04-27.
 */
import { CARPARTS } from '../car-parts/mocks';
import { Injectable } from '@angular/core';
import {CarPart} from "../car-parts/car-part";

@Injectable()
export class RacingDataService {

    getCarParts() {
        return CARPARTS;
    }

    addCarPart(carPart: CarPart) {
        CARPARTS.push(carPart);
        return this.getCarParts();
    }
}