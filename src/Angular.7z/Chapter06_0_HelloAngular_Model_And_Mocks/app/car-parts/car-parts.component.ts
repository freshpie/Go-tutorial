/**
 * Created by 206-001 on 2017-04-25.
 */
import { Component } from '@angular/core';
import {CarPart} from "./car-part";
import {CARPARTS} from "./mocks";

@Component({
    selector: "car-parts",
    templateUrl: "app/car-parts/car-parts.component.html",
    styleUrls: ["app/car-parts/car-parts.component.css"]
})
export class CarPartsComponent {

    carParts: CarPart[];

    ngOnInit() {
        console.log("초기화");
        alert("초기화 완료");
        this.carParts = CARPARTS;
    }

    totalCarParts(): number {
        // let sum: number = 0;
        // for ( let carPart of this.carParts ) {
        //     sum += carPart.inStock;
        // }
        // return sum;

        // return this.carParts.reduce( function ( prev, current ) { return prev + current.inStock}, 0 );
        return this.carParts.reduce( ( prev, current ) => prev + current.inStock, 0 );
    }
}