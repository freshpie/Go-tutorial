/**
 * Created by 206-001 on 2017-04-26.
 */
export class CarPart {
    id: number;
    name: string;
    // name: string | number;
    description: string;
    inStock: number;
    price: number;
    // price: any;
    image: string;
    featured: boolean;
}