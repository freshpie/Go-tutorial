
import { Component, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { MyDatePipe } from './custom/pipe/mydate.pipe'
import { AppComponent } from './app.component';
import { CarPartsComponent } from './car-parts/car-parts.component';
import {FooterModule} from "./footer/footer.module";

@NgModule({
    declarations: [ AppComponent, CarPartsComponent, MyDatePipe ],
    imports: [BrowserModule, FooterModule, FormsModule],
    bootstrap: [ AppComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);