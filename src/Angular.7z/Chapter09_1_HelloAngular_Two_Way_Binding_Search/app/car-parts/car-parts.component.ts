/**
 * Created by 206-001 on 2017-04-25.
 */
import { Component } from '@angular/core';
import {CarPart} from "./car-part";
import {CARPARTS} from "./mocks";

@Component({
    selector: "car-parts",
    templateUrl: "app/car-parts/car-parts.component.html",
    styleUrls: ["app/car-parts/car-parts.component.css"]
})
export class CarPartsComponent {

    carParts: CarPart[];

    ngOnInit() {
        this.carParts = CARPARTS;

        (function(carParts, func) {
            setTimeout(function() { func(carParts) }, 5000);
        })(this.carParts, this.changeImage);
    }

    totalCarParts(): number {
        // let sum: number = 0;
        // for ( let carPart of this.carParts ) {
        //     sum += carPart.inStock;
        // }
        // return sum;

        // return this.carParts.reduce( function ( prev, current ) { return prev + current.inStock}, 0 );
        return this.carParts.reduce( ( prev, current ) => prev + current.inStock, 0 );
    }

    changeImage(carParts) {
        carParts[0].image="https://t1.daumcdn.net/daumtop_chanel/op/20170315064553027.png";
    }

    upQuantity(carPart) {
        // alert(carPart.name + "증가");
        if ( carPart.inStock > carPart.quantity )
            carPart.quantity++;
    }

    downQuantity(carPart) {
        //alert(carPart.name + "감소");
        if(carPart.quantity > 0)
            carPart.quantity--;
    }

    search(stockValue: number) {
        console.log(stockValue);
        this.carParts = CARPARTS.filter( carPart =>  carPart.inStock >= stockValue);
    }
}