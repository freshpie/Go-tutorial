
import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

@Component({
    selector: "my-app",
    template: `<h1>{{title}}</h1>
    <!--<h2>{{carPart.id}}</h2>-->
    <h2>{{carPart.name}}</h2>
    <p>{{carPart.description}}</p>
    <p>{{carPart.inStock}}</p>`
})
class AppComponent {
    title= "Ultra Racing";

    carPart = {
        "id": 1,
        "name": "Super Tires",
        "description": "These tires are the very best.",
        "inStock": 5
    };
}

@NgModule({
    declarations: [ AppComponent ],
    imports: [BrowserModule],
    bootstrap: [ AppComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);