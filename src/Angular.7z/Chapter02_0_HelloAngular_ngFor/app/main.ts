
import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

@Component({
    selector: "my-app",
    template: `<h1>{{title}}</h1>
    <!--<h2>{{carPart.id}}</h2>-->
    <ul>
        <li *ngFor="let carPart of carParts; let i = index">
            <h2>{{i+1}}번째 아이템 : {{carPart.name}}</h2>
            <p>{{carPart.description}}</p>
            <p *ngIf="carPart.inStock > 0">{{carPart.inStock}} in Stock</p>
            <p *ngIf="carPart.inStock === 0">Out of Stock</p>
            <div [ngSwitch]="count">
                <p *ngSwitchCase="3">가장 많음.</p>
                <p *ngSwitchCase="2">보통</p>
                <p *ngSwitchCase="1">가장 적음.</p>
                <p *ngSwitchDefault>없음.</p>
            </div>
        </li>
    </ul>`

})
class AppComponent {
    title= "Ultra Racing";

    count = 0;

    carParts = [{
        "id": 1,
        "name": "Super Tires",
        "description": "These tires are the very best.",
        "inStock": 5
    }, {
        "id": 2,
        "name": "Reinforced Shocks",
        "description": "Shocks made from Kryptonite",
        "inStock": 4
    }, {
        "id": 1,
        "name": "Padded Seats",
        "description": "Super soft seats for a smooth ride.",
        "inStock": 0
    }];
}

@NgModule({
    declarations: [ AppComponent ],
    imports: [BrowserModule],
    bootstrap: [ AppComponent ]
})
class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);