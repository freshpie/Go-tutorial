/**
 * Created by 206-001 on 2017-04-28.
 */
import { Component } from '@angular/core';

@Component({
    selector: 'about',
    template: `
        <header class="container">
            <h1>Something about race</h1>
                        
            <p>Races are usally pretty awesome. shedule to race today</p>
        </header>
    `
})
export class AboutComponent { }