/**
 * Created by 206-001 on 2017-04-25.
 */
import { Component } from '@angular/core';

@Component({
    selector: "my-app",
    template: `<h1>{{title}}</h1>
    <ul class="nav navbar-nav navbar-right">
        <li> <a [routerLink]="['']">About</a> </li>
        <li> <a [routerLink]="['/carpart']">CarPart</a> </li>
    </ul>
    <router-outlet></router-outlet>
    <footer></footer>`
})
export class AppComponent {
    title= "Ultra Racing";
    dateStr = "20170425";
}